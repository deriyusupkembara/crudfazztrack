@extends('app')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title">{{ $title }}</h3>
            </div>
            <!-- form start -->
            <form action="{{ route('products.update', $product->id) }}" role="form" method="POST">
                @csrf
                @method('PATCH')
                @include('product.form')
                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" class="btn btn-warning">Ubah</button>
                    <a href="{{ route('products') }}" class="btn btn-secondary float-right">Batal</a>
                </div>
            </form>
        </div>
        <!-- /.card -->
    </div>
    <!-- /.col -->
</div>
@endsection

