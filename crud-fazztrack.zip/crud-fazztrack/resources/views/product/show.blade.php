@extends('app')

@section('content')
<div class="card card-solid">
    <div class="card-body">
        <div class="row">
            <div class="col-12 col-sm-3">
                <h3 class="d-inline-block d-sm-none">LOWA Men’s Renegade GTX Mid Hiking Boots Review</h3>
                <div class="col-12">
                    <img src="{{ asset('images/barang/'.$barang->gambar) }}" class="product-image" alt="Product Image">
                </div>
            </div>
            <div class="col-12 col-sm-9">
                <h3 class="my-3">{{ $barang->nama }}</h3>
                <p>Ukuran : {{ $barang->ukuran }}</p>
                <hr>
                <p>Warna : {{ $barang->warna }}</p>
                <hr>
                <p>Stock : {{ $barang->stock }}</p>
                <hr>
                <p>Distributor : {{ $barang->distributor_id }}</p>
                <hr>
            </div>
            <div class="col-12">
                <a href="{{ route('barangs') }}" class="btn btn-secondary">Kembali</a>
            </div>
        </div>
    </div>
    <!-- /.card-body -->
</div>
@endsection
