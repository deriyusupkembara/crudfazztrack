@extends('app')

@section('content')
<div class="row">
    <div class="col-6">
        <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title">{{ $title }}</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="{{ route('products.store') }}" role="form" method="POST">
                @csrf
                @include('product.form')

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    <a href="/products" class="btn btn-secondary float-right">Batal</a>
                </div>
            </form>
        </div>
        <!-- /.card -->
    </div>
    <!-- /.col -->
</div>
@endsection
