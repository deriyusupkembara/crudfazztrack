<div class="card">
	<div class="card-body">
		<div class="form-group">
			<label>nama_produk</label>
			<input type="text" name="nama_produk" class="form-control{{ $errors->has('nama_produk') ? ' is-invalid' : '' }}" placeholder="Nama Produk"
				value="{{ $product->nama_produk ?? request()->old('nama_produk') }}">
			<div class="invalid-feedback">
				{{ $errors->has('nama_produk') ? $errors->first('nama_produk') : '' }}
			</div>
		</div>
		<div class="form-group">
			<label>Keterangan</label>
			<textarea name="keterangan" class="form-control{{ $errors->has('keterangan') ? ' is-invalid' : '' }}" placeholder="Keterangan">{{ $product->keterangan ?? request()->old('keterangan') }}</textarea>
			<div class="invalid-feedback">
				{{ $errors->has('keterangan') ? $errors->first('keterangan') : '' }}
			</div>
		</div>
		<div class="form-group">
			<label>Jumlah</label>
			<input type="text" name="jumlah" class="form-control{{ $errors->has('jumlah') ? ' is-invalid' : '' }}" placeholder="Jumlah"
				value="{{ $product->jumlah ?? request()->old('jumlah') }}">
			<div class="invalid-feedback">
				{{ $errors->has('jumlah') ? $errors->first('jumlah') : '' }}
			</div>
		</div>
		<div class="form-group">
			<label>Harga</label>
			<input type="text" name="harga" class="form-control{{ $errors->has('harga') ? ' is-invalid' : '' }}" placeholder="Harga"
				value="{{ $product->harga ?? request()->old('harga') }}">
			<div class="invalid-feedback">
				{{ $errors->has('harga') ? $errors->first('harga') : '' }}
			</div>
		</div>
	</div>
</div>
