@extends('app')

@section('content')
@if (session('message'))
    <div class="alert alert-success" style="opacity: 0.8">
        {{ session('message') }}
    </div>
@endif
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">{{ $title }}</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                {{-- <div class="d-flex justify-content-end"> --}}
                <div class="">
                    <a href="{{ url('products/create') }}" class="btn btn-info mb-3">
                        <i class="fas fa-plus"></i> Product
                    </a>
                </div>
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Keterangan</th>
                            <th>Jumlah</th>
                            <th>Harga</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $n=1 ?>
                        @foreach ($products as $product)
                        <tr>
                            <td class="text-center">{{ $n++ }}</td>
                            <td>{{ $product->nama_produk }}</td>
                            <td>{{ $product->keterangan }}</td>
                            <td>{{ $product->jumlah }}</td>
                            <td>IDR {{ number_format($product->harga) }}</td>
                            <td class="d-flex justify-content-center">
                                <a class="btn btn-info mr-1" href="{{ route('products.edit', $product->id) }}" title="Edit">
                                    <i class="fas fa-pencil-alt">
                                    </i>
                                    Edit
                                </a>

                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-danger" data-toggle="modal" title="Delete"
                                    data-target="#exampleModal{{ $product->id }}">
                                    <i class="fas fa-trash">
                                    </i>
                                    Delete
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal{{ $product->id }}" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Delete</h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                Yakin Ingin Menghapus Data ini ?
                                                <hr>
                                                <div class="row mt-1">
                                                    <div class="col-12 ">
                                                        <h3>{{ $product->nama_produk }}</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-between">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Close</button>
                                                <form action="{{ route('products.destroy', $product->id) }}" method="post">
                                                    @csrf
                                                    @method('delete')
                                                    <button class="btn btn-danger" type="submit">Delete</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.col -->
</div>
@endsection
