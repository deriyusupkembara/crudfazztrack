<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title"><?php echo e($title); ?></h3>
            </div>
            <!-- form start -->
            <form action="<?php echo e(route('products.update', $product->id)); ?>" role="form" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <?php echo $__env->make('product.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- /.card-body -->
                <div class="card-footer">
                    <button type="submit" class="btn btn-warning">Ubah</button>
                    <a href="<?php echo e(route('products')); ?>" class="btn btn-secondary float-right">Batal</a>
                </div>
            </form>
        </div>
        <!-- /.card -->
    </div>
    <!-- /.col -->
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/neemu/scratch/project/crud-fazztrack/resources/views/product/edit.blade.php ENDPATH**/ ?>