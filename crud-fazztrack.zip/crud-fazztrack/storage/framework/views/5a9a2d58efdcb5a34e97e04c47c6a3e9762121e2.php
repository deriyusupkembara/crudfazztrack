<div class="card">
	<div class="card-body">
		<div class="form-group">
			<label>nama_produk</label>
			<input type="text" name="nama_produk" class="form-control<?php echo e($errors->has('nama_produk') ? ' is-invalid' : ''); ?>" placeholder="Nama Produk"
				value="<?php echo e($product->nama_produk ?? request()->old('nama_produk')); ?>">
			<div class="invalid-feedback">
				<?php echo e($errors->has('nama_produk') ? $errors->first('nama_produk') : ''); ?>

			</div>
		</div>
		<div class="form-group">
			<label>Keterangan</label>
			<textarea name="keterangan" class="form-control<?php echo e($errors->has('keterangan') ? ' is-invalid' : ''); ?>" placeholder="Keterangan"><?php echo e($product->keterangan ?? request()->old('keterangan')); ?></textarea>
			<div class="invalid-feedback">
				<?php echo e($errors->has('keterangan') ? $errors->first('keterangan') : ''); ?>

			</div>
		</div>
		<div class="form-group">
			<label>Jumlah</label>
			<input type="text" name="jumlah" class="form-control<?php echo e($errors->has('jumlah') ? ' is-invalid' : ''); ?>" placeholder="Jumlah"
				value="<?php echo e($product->jumlah ?? request()->old('jumlah')); ?>">
			<div class="invalid-feedback">
				<?php echo e($errors->has('jumlah') ? $errors->first('jumlah') : ''); ?>

			</div>
		</div>
		<div class="form-group">
			<label>Harga</label>
			<input type="text" name="harga" class="form-control<?php echo e($errors->has('harga') ? ' is-invalid' : ''); ?>" placeholder="Harga"
				value="<?php echo e($product->harga ?? request()->old('harga')); ?>">
			<div class="invalid-feedback">
				<?php echo e($errors->has('harga') ? $errors->first('harga') : ''); ?>

			</div>
		</div>
	</div>
</div>
<?php /**PATH /home/neemu/scratch/project/crud-fazztrack/resources/views/product/form.blade.php ENDPATH**/ ?>