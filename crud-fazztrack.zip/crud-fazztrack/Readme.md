﻿Screen Shoot Aplikasi

1. Create data

2. Read data

3. Update data

4. Delete data

