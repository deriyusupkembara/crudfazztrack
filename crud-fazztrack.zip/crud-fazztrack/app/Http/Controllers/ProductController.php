<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use PhpParser\Node\Stmt\Foreach_;

class ProductController extends Controller
{
    private $url = 'products';
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = [
            'url' => $this->url,
            'title' => 'Products',
            'products' => Product::orderByDesc('id')->get(),
        ];

        return view('product.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'url' => $this->url,
            'title' => 'Create Product',
            'product' => new Product(),
        ];

        return view('product.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Validator::make($request->all(), [
            'nama_produk' => 'required',
            'keterangan' => 'required',
            'harga' => 'required|numeric|gt:0',
            'jumlah' => 'required|numeric|gt:0',
        ])->validate();

        Product::create($request->all());

        return redirect('products')->with('message', 'Product has Added');
    }
	
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Room  $product
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = [
            'url' => $this->url,
            'title' => 'Edit Product',
            'product' => Product::find($id),
        ];

        return view('product.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Room  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
		
        Validator::make($request->all(), [
            'nama_produk' => 'required',
            'keterangan' => 'required',
            'harga' => 'required|numeric|gt:0',
            'jumlah' => 'required|numeric|gt:0',
        ])->validate();
		
        $product = Product::find($id);

        $product->nama_produk = $request->nama_produk;
        $product->keterangan = $request->keterangan;
        $product->harga = $request->harga;
        $product->jumlah = $request->jumlah;

        $product->save();

        return redirect('products')->with('message', 'Product has Updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Room  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::find($id);

        $product->delete();

        return redirect('products')->with('message', 'Product has Deleted');
    }
}
